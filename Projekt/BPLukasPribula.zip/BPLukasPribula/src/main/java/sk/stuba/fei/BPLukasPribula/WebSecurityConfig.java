package sk.stuba.fei.BPLukasPribula;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import sk.stuba.fei.BPLukasPribula.service.UserDetailsServiceImpl;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Bean
    public UserDetailsService userDetailsService() {
        return new UserDetailsServiceImpl();
    }

    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService());
        authProvider.setPasswordEncoder(passwordEncoder());

        return authProvider;
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(authenticationProvider());
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable().authorizeRequests()

                .antMatchers("/css1.css").permitAll()
                .antMatchers("/img/**").permitAll()
                .antMatchers("/js/**").permitAll()
                .antMatchers("/vytvaranieOsoby").hasAnyAuthority("ADMIN", "CREATOR", "EDITOR")
                .antMatchers("/vytvaranieDruzstva").hasAnyAuthority("ADMIN", "CREATOR", "EDITOR")
                .antMatchers("/vytvaranieAdresy").hasAnyAuthority("ADMIN", "CREATOR", "EDITOR")
                .antMatchers("/vytvaranieLigy").hasAnyAuthority("ADMIN", "CREATOR", "EDITOR")
                .antMatchers("/vytvaranieVybavenia").hasAnyAuthority("ADMIN", "CREATOR", "EDITOR")
                .antMatchers("/vytvaranieZapasu").hasAnyAuthority("ADMIN", "CREATOR", "EDITOR")
                .antMatchers("/kartaOsob/detail/uprava/**").hasAnyAuthority("ADMIN", "CREATOR", "EDITOR")
                .antMatchers("/kartaDruzstiev/detail/upravaDruzstva/**").hasAnyAuthority("ADMIN", "CREATOR", "EDITOR")
                .antMatchers("/kartaAdries/upravaAdresy/**").hasAnyAuthority("ADMIN", "CREATOR", "EDITOR")
                .antMatchers("/kartaVybavenia/upravaVybavenia/**").hasAnyAuthority("ADMIN", "CREATOR", "EDITOR")
                .antMatchers("/kartaZapasov/upravaZapasu/**").hasAnyAuthority("ADMIN", "CREATOR", "EDITOR")
                .antMatchers("/vytvaraniePokuty").hasAnyAuthority("ADMIN", "CREATOR", "EDITOR")
                .antMatchers("/index").permitAll()
                .antMatchers("/kartaOsob").permitAll()
                .antMatchers("/kartaPokut").permitAll()
                .antMatchers("/kartaOsob/detail/**").permitAll()
                .antMatchers("/kartaDruzstiev").permitAll()
                .antMatchers("/kartaDruzstiev/detail/**").permitAll()
                .antMatchers("/kartaAdries").permitAll()
                .antMatchers("/kartaVybavenia").permitAll()
                .antMatchers("/kartaZapasov").permitAll()
                .antMatchers("/kartaZapasov/detailZapasu/**").permitAll()
                .antMatchers("/uspesnost").permitAll()
                .antMatchers("/uspesnostZakladna").permitAll()
                .antMatchers("/uspesnostBodovyKoeficient").permitAll()
                .antMatchers("/uspesnostELO").permitAll()
                .antMatchers("/").permitAll()

                .anyRequest().authenticated()
                .and()
                .formLogin().permitAll()
                .and()
                .logout().permitAll()
                .and()
                .exceptionHandling().accessDeniedPage("/403")

        ;
    }
}