package sk.stuba.fei.BPLukasPribula.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sk.stuba.fei.BPLukasPribula.repository.ZapasRepository;

@Service
public class ZapasService {
    @Autowired
    private ZapasRepository zapasRepository;

    public ZapasService(ZapasRepository zapasRepository) {
        this.zapasRepository = zapasRepository;
    }
}
