package sk.stuba.fei.BPLukasPribula.contoller;

import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import sk.stuba.fei.BPLukasPribula.druzstvo.Adresa;
import sk.stuba.fei.BPLukasPribula.druzstvo.Druzstvo;
import sk.stuba.fei.BPLukasPribula.repository.DruzstvoRepository;
import sk.stuba.fei.BPLukasPribula.repository.VybavenieDruzstvaRepository;
import sk.stuba.fei.BPLukasPribula.repository.VybavenieRepository;
import sk.stuba.fei.BPLukasPribula.vybavenie.Vybavenie;
import sk.stuba.fei.BPLukasPribula.vybavenie.VybavenieDruzstva;

import java.util.List;

@Data
@Component
@Controller
public class VybavenieController {

    @Autowired
    private VybavenieRepository vybavenieRepository;
    private VybavenieDruzstvaRepository vybavenieDruzstvaRepository;
    private DruzstvoRepository druzstvoRepository;

    public VybavenieController(VybavenieRepository vybavenieRepository, VybavenieDruzstvaRepository vybavenieDruzstvaRepository, DruzstvoRepository druzstvoRepository) {
        this.vybavenieRepository = vybavenieRepository;
        this.vybavenieDruzstvaRepository = vybavenieDruzstvaRepository;
        this.druzstvoRepository = druzstvoRepository;
    }

    @GetMapping("/vytvaranieVybavenia")
    public String vytvaranieVybavenia(Model model) {

        model.addAttribute("vybavenie", new Vybavenie());
        List<Druzstvo> vyberDruzstva = druzstvoRepository.findAll();
        model.addAttribute("vyberDruzstva", vyberDruzstva);
        model.addAttribute("vybavenieDruzstva", new VybavenieDruzstva());
        return "html/vytvaranieVybavenia";

    }

    @PostMapping("/vytvaranieVybavenia")
    public String submitVytvaranieVybavenia(@ModelAttribute Vybavenie vybavenie, VybavenieDruzstva vybavenieDruzstva, Model model) {



        this.vybavenieRepository.save(vybavenie);
        int id = vybavenie.getIdVybavenia();

        vybavenieDruzstva.setIdVybavenia(id);
        this.vybavenieDruzstvaRepository.save(vybavenieDruzstva);
        return "redirect:/index";

    }

    @GetMapping("/kartaVybavenia")
    public String kartaVybavenia( Model model) {


        model.addAttribute("vybavenie",vybavenieRepository.findAll());
        model.addAttribute("vybavenieDruzstva",vybavenieDruzstvaRepository.findAll());
        model.addAttribute("druzstva",druzstvoRepository.findAll());

        return "html/vybavenie/kartaVybavenia";
    }

    @GetMapping("kartaVybavenia/upravaVybavenia/{id}")
    public String upravaVybavenia(@PathVariable int id, Model model) {

        model.addAttribute("vybavenieUprava", vybavenieRepository.findById(id).get());
        List<Druzstvo> vyberDruzstva = druzstvoRepository.findAll();
        model.addAttribute("vyberDruzstva", vyberDruzstva);

        model.addAttribute("vybavenieDruzstva",vybavenieDruzstvaRepository.findById(id).get());

        return "html/vybavenie/upravaVybavenia";
    }

    @PostMapping("/upravaVybavenia/{id}")
    public String submitUpravaVybavenia( @PathVariable  Integer id, Vybavenie vybavenie, VybavenieDruzstva vybavenieDruzstva) {

        vybavenie.setIdVybavenia(id);

        this.vybavenieRepository.save(vybavenie);
        int idVybavenia = vybavenie.getIdVybavenia();

        vybavenieDruzstva.setIdVybavenia(idVybavenia);
        this.vybavenieDruzstvaRepository.save(vybavenieDruzstva);


        return "redirect:/kartaVybavenia";
    }

}
