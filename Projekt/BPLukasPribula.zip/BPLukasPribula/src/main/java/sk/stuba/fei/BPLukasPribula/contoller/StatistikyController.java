package sk.stuba.fei.BPLukasPribula.contoller;

import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import sk.stuba.fei.BPLukasPribula.repository.*;

@Data
@Component
@Controller
public class StatistikyController {

    private ZapasRepository zapasRepository;
    private OdohravanieZapasuRepository odohravanieZapasuRepository;
    private OsobaRepository osobaRepository;
    private SkoreZapasovRepository skoreZapasovRepository;
    private ZapisHracaDruzstvuRepository zapisHracaDruzstvuRepository;

    @Autowired
    public StatistikyController(ZapasRepository zapasRepository, OdohravanieZapasuRepository odohravanieZapasuRepository, OsobaRepository osobaRepository, SkoreZapasovRepository skoreZapasovRepository, ZapisHracaDruzstvuRepository zapisHracaDruzstvuRepository) {
        this.zapasRepository = zapasRepository;
        this.odohravanieZapasuRepository = odohravanieZapasuRepository;
        this.osobaRepository = osobaRepository;
        this.skoreZapasovRepository = skoreZapasovRepository;
        this.zapisHracaDruzstvuRepository = zapisHracaDruzstvuRepository;
    }

    @GetMapping("/uspesnost")
    public String uspesnostStatistika( Model model) {

        model.addAttribute("skoreZapasov",skoreZapasovRepository.findAll());
        model.addAttribute("osoby",osobaRepository.findAll());



        return "html/statistiky/uspesnost";
    }

    @GetMapping("/uspesnostZakladna")
    public String uspesnostZakladnaStatistika( Model model) {

        model.addAttribute("skoreZapasov",skoreZapasovRepository.findAll());
        model.addAttribute("osoby",osobaRepository.findAll());

        return "html/statistiky/uspesnostZakladna";
    }

    @GetMapping("/uspesnostBodovyKoeficient")
    public String uspesnostBodovyKoeficient( Model model) {

        model.addAttribute("skoreZapasov",skoreZapasovRepository.findAll());
        model.addAttribute("osoby",osobaRepository.findAll());

        return "html/statistiky/uspesnostBodovyKoeficient";
    }

    @GetMapping("/uspesnostELO")
    public String uspesnostELO( Model model) {

        model.addAttribute("skoreZapasov",skoreZapasovRepository.findAll());
        model.addAttribute("osoby",osobaRepository.findAll());

        return "html/statistiky/uspesnostELO";
    }

}
