package sk.stuba.fei.BPLukasPribula.tabulka;

public class Tabulka{

    private int idDruzstva;
    private String nazovDruzstva;
    private int body;

    public Tabulka() {
    }

    public Tabulka(int idDruzstva, String nazovDruzstva, int body) {
        this.idDruzstva = idDruzstva;
        this.nazovDruzstva = nazovDruzstva;
        this.body = body;
    }

    public int getIdDruzstva() {
        return idDruzstva;
    }

    public void setIdDruzstva(int idDruzstva) {
        this.idDruzstva = idDruzstva;
    }

    public String getNazovDruzstva() {
        return nazovDruzstva;
    }

    public void setNazovDruzstva(String nazovDruzstva) {
        this.nazovDruzstva = nazovDruzstva;
    }

    public int getBody() {
        return body;
    }

    public void setBody(int body) {
        this.body = body;
    }

}
