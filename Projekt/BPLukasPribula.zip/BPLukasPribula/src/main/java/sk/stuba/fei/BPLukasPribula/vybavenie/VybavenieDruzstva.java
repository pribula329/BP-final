package sk.stuba.fei.BPLukasPribula.vybavenie;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "vybaveniedruzstva")
@Entity
public class VybavenieDruzstva {

    @Column(name = "id_druzstva")
    private Integer idDruzstva;
    @Id
    @Column(name = "id_vybavenia")
    private int idVybavenia;
    @Column(name = "pocet")
    private int pocet;
}
