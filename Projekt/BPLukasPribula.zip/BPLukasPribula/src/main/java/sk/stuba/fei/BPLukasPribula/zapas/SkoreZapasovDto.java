package sk.stuba.fei.BPLukasPribula.zapas;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SkoreZapasovDto {

    private List<SkoreZapasov> listSkoreZapasov = new ArrayList<>();

    public void pridajSkoreZapasov(SkoreZapasov skoreZapasov){
        this.listSkoreZapasov.add(skoreZapasov);
    }

    public void zadajVyhercu(){

        for (int i =0; i<this.listSkoreZapasov.size();i++){
            SkoreZapasov aktualneSkore=this.listSkoreZapasov.get(i);
            System.out.println(aktualneSkore.getSkore());
            if ((aktualneSkore.getSkore().equals("3:0")) || (aktualneSkore.getSkore().equals("3:1")) || (aktualneSkore.getSkore().equals("3:2"))){
                aktualneSkore.setVitaz(1);
            }
            else {
                aktualneSkore.setVitaz(2);
            }
        }

    }

    public void zadajKolo(int kolo){

        for (int i =0; i<this.listSkoreZapasov.size();i++){
            SkoreZapasov aktualneSkore=this.listSkoreZapasov.get(i);

            aktualneSkore.setKolo(kolo);

        }

    }


}
