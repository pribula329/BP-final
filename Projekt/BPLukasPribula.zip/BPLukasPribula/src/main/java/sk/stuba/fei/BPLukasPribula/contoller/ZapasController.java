package sk.stuba.fei.BPLukasPribula.contoller;

import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import sk.stuba.fei.BPLukasPribula.druzstvo.Druzstvo;

import sk.stuba.fei.BPLukasPribula.osoba.Osoba;

import sk.stuba.fei.BPLukasPribula.repository.*;

import sk.stuba.fei.BPLukasPribula.zapas.OdohravanieZapasu;
import sk.stuba.fei.BPLukasPribula.zapas.SkoreZapasov;
import sk.stuba.fei.BPLukasPribula.zapas.SkoreZapasovDto;
import sk.stuba.fei.BPLukasPribula.zapas.Zapas;

import java.util.ArrayList;
import java.util.List;

@Data
@Component
@Controller
public class ZapasController {

    private ZapasRepository zapasRepository;
    private OdohravanieZapasuRepository odohravanieZapasuRepository;
    private DruzstvoRepository druzstvoRepository;
    private OsobaRepository osobaRepository;
    private SkoreZapasovRepository skoreZapasovRepository;
    private ZapisHracaDruzstvuRepository zapisHracaDruzstvuRepository;
    @Autowired
    public ZapasController(ZapasRepository zapasRepository, OdohravanieZapasuRepository odohravanieZapasuRepository, DruzstvoRepository druzstvoRepository, OsobaRepository osobaRepository, SkoreZapasovRepository skoreZapasovRepository, ZapisHracaDruzstvuRepository zapisHracaDruzstvuRepository) {
        this.zapasRepository = zapasRepository;
        this.odohravanieZapasuRepository = odohravanieZapasuRepository;
        this.druzstvoRepository = druzstvoRepository;
        this.osobaRepository = osobaRepository;
        this.skoreZapasovRepository = skoreZapasovRepository;
        this.zapisHracaDruzstvuRepository = zapisHracaDruzstvuRepository;
    }





    @GetMapping("/vytvaranieZapasu")
    public String vytvaranieZapasu(Model model) {

        model.addAttribute("zapas", new Zapas());
        model.addAttribute("odohravanieZapasu", new OdohravanieZapasu());
        List<Druzstvo> vyberDruzstvaNaZapas = druzstvoRepository.findAll();
        model.addAttribute("vyberDruzstvaNaZapas", vyberDruzstvaNaZapas);
        model.addAttribute("najdeniRozhodcovia", hladanieRozhodcov(this.osobaRepository));
        //pre javascript
        model.addAttribute("osoby", osobaRepository.findAll());
        model.addAttribute("osobyIbaHraci", zapisHracaDruzstvuRepository.findAll());
        List<Osoba> hraciDomaci = new ArrayList<>();
        List<Osoba> hraciHostia = new ArrayList<>();
        model.addAttribute("hraciDomaci", hraciDomaci);
        model.addAttribute("hraciHostia",hraciHostia);

      /*  Druzstvo druzstvoDomaci = druzstvoRepository.getOne(78);
        Druzstvo druzstvoHostia = druzstvoRepository.getOne(66);
        model.addAttribute("hraciDomaci", hladanieHracov(druzstvoDomaci,this.zapisHracaDruzstvuRepository,this.osobaRepository));
        model.addAttribute("hraciHostia", hladanieHracov(druzstvoHostia,this.zapisHracaDruzstvuRepository,this.osobaRepository));
        */
        SkoreZapasovDto skoreZapasovDto = new SkoreZapasovDto();
        for (int i=1; i<=16; i++){
            skoreZapasovDto.pridajSkoreZapasov(new SkoreZapasov());
        }
        model.addAttribute("zapasy",skoreZapasovDto);
        /* model.addAttribute("skore1",new SkoreZapasov());
        model.addAttribute("skore2",new SkoreZapasov());
        model.addAttribute("skore3",new SkoreZapasov());
        model.addAttribute("skore4",new SkoreZapasov());
        model.addAttribute("skore5",new SkoreZapasov());
        model.addAttribute("skore6",new SkoreZapasov());
        model.addAttribute("skore7",new SkoreZapasov());
        model.addAttribute("skore8",new SkoreZapasov());
        model.addAttribute("skore9",new SkoreZapasov());
        model.addAttribute("skore10",new SkoreZapasov());
        model.addAttribute("skore11",new SkoreZapasov());
        model.addAttribute("skore12",new SkoreZapasov());
        model.addAttribute("skore13",new SkoreZapasov());
        model.addAttribute("skore14",new SkoreZapasov());
        model.addAttribute("skore15",new SkoreZapasov());
        model.addAttribute("skore16",new SkoreZapasov());*/

        return "html/vytvaranieZapasu";

    }

    private List<Osoba> hladanieRozhodcov(OsobaRepository osobaRepository){

        List<Osoba> najdeniRozhodcovia = new ArrayList<>();
        for (int i=0; i<osobaRepository.findAll().size(); i++){
            Osoba aktualny = osobaRepository.findAll().get(i);
            if (aktualny.isTypR()==true){
                najdeniRozhodcovia.add(osobaRepository.getOne(aktualny.getIdOsoba()));
            }
        }

        return  najdeniRozhodcovia;
    }

  /*  private List<Osoba> hladanieHracov(Druzstvo druzstvo, ZapisHracaDruzstvuRepository zapisHracaDruzstvuRepository, OsobaRepository osobaRepository){

        List<Osoba> najdenyHraci = new ArrayList<>();
        for (int i=0; i<zapisHracaDruzstvuRepository.findAll().size(); i++)
        {
            ZapisHracaDruzstvu aktualny = zapisHracaDruzstvuRepository.findAll().get(i);
            if (aktualny.getIdDruzstva() == druzstvo.getIdDruzstvo())
            {
                najdenyHraci.add(osobaRepository.getOne(aktualny.getIdHraca()));
            }
        }

        return najdenyHraci;
    }
*/

    @PostMapping("/vytvaranieZapasu")
    public String submitVytvaranieZapasu(@ModelAttribute Zapas zapas, OdohravanieZapasu odohravanieZapasu, SkoreZapasovDto skoreZapasovDto /*SkoreZapasov zapas1, SkoreZapasov zapas2,SkoreZapasov zapas3,SkoreZapasov zapas4,SkoreZapasov zapas5,SkoreZapasov zapas6,SkoreZapasov zapas7,SkoreZapasov zapas8,SkoreZapasov zapas9,SkoreZapasov zapas10,SkoreZapasov zapas11,SkoreZapasov zapas12,SkoreZapasov zapas13,SkoreZapasov zapas14,SkoreZapasov zapas15,SkoreZapasov zapas16, Model model*/) {

        skoreZapasovDto.zadajVyhercu();
        skoreZapasovDto.zadajKolo(odohravanieZapasu.getIdKolo());
        this.skoreZapasovRepository.save(skoreZapasovDto.getListSkoreZapasov().get(0));
        zapas.setSkore1(skoreZapasovDto.getListSkoreZapasov().get(0).getIdSkoreZapasu());
        this.skoreZapasovRepository.save(skoreZapasovDto.getListSkoreZapasov().get(1));
        zapas.setSkore2(skoreZapasovDto.getListSkoreZapasov().get(1).getIdSkoreZapasu());
        this.skoreZapasovRepository.save(skoreZapasovDto.getListSkoreZapasov().get(2));
        zapas.setSkore3(skoreZapasovDto.getListSkoreZapasov().get(2).getIdSkoreZapasu());
        this.skoreZapasovRepository.save(skoreZapasovDto.getListSkoreZapasov().get(3));
        zapas.setSkore4(skoreZapasovDto.getListSkoreZapasov().get(3).getIdSkoreZapasu());
        this.skoreZapasovRepository.save(skoreZapasovDto.getListSkoreZapasov().get(4));
        zapas.setSkore5(skoreZapasovDto.getListSkoreZapasov().get(4).getIdSkoreZapasu());
        this.skoreZapasovRepository.save(skoreZapasovDto.getListSkoreZapasov().get(5));
        zapas.setSkore6(skoreZapasovDto.getListSkoreZapasov().get(5).getIdSkoreZapasu());
        this.skoreZapasovRepository.save(skoreZapasovDto.getListSkoreZapasov().get(6));
        zapas.setSkore7(skoreZapasovDto.getListSkoreZapasov().get(6).getIdSkoreZapasu());
        this.skoreZapasovRepository.save(skoreZapasovDto.getListSkoreZapasov().get(7));
        zapas.setSkore8(skoreZapasovDto.getListSkoreZapasov().get(7).getIdSkoreZapasu());
        this.skoreZapasovRepository.save(skoreZapasovDto.getListSkoreZapasov().get(8));
        zapas.setSkore9(skoreZapasovDto.getListSkoreZapasov().get(8).getIdSkoreZapasu());
        this.skoreZapasovRepository.save(skoreZapasovDto.getListSkoreZapasov().get(9));
        zapas.setSkore10(skoreZapasovDto.getListSkoreZapasov().get(9).getIdSkoreZapasu());
        this.skoreZapasovRepository.save(skoreZapasovDto.getListSkoreZapasov().get(10));
        zapas.setSkore11(skoreZapasovDto.getListSkoreZapasov().get(10).getIdSkoreZapasu());
        this.skoreZapasovRepository.save(skoreZapasovDto.getListSkoreZapasov().get(11));
        zapas.setSkore12(skoreZapasovDto.getListSkoreZapasov().get(11).getIdSkoreZapasu());
        this.skoreZapasovRepository.save(skoreZapasovDto.getListSkoreZapasov().get(12));
        zapas.setSkore13(skoreZapasovDto.getListSkoreZapasov().get(12).getIdSkoreZapasu());
        this.skoreZapasovRepository.save(skoreZapasovDto.getListSkoreZapasov().get(13));
        zapas.setSkore14(skoreZapasovDto.getListSkoreZapasov().get(13).getIdSkoreZapasu());
        this.skoreZapasovRepository.save(skoreZapasovDto.getListSkoreZapasov().get(14));
        zapas.setSkore15(skoreZapasovDto.getListSkoreZapasov().get(14).getIdSkoreZapasu());
        this.skoreZapasovRepository.save(skoreZapasovDto.getListSkoreZapasov().get(15));
        zapas.setSkore16(skoreZapasovDto.getListSkoreZapasov().get(15).getIdSkoreZapasu());

        this.zapasRepository.save(zapas);
        int idZapasu = zapas.getIdZapasu();
        odohravanieZapasu.setIdZapas(idZapasu);
        this.odohravanieZapasuRepository.save(odohravanieZapasu);




        return "redirect:/index";

    }

    @GetMapping("/kartaZapasov")
    public String kartaZapasov( Model model) {


        model.addAttribute("zapas",zapasRepository.findAll());
        model.addAttribute("druzstva",druzstvoRepository.findAll());
        model.addAttribute("odohravanie",odohravanieZapasuRepository.findAll());



        return "html/zapas/kartaZapasov";
    }

    @GetMapping("kartaZapasov/detailZapasu/{id}")
    public String detailZapasu(@PathVariable int id, Model model) {

        model.addAttribute("zapasDetail", zapasRepository.findById(id).get());
        model.addAttribute("skoreDetail", skoreZapasovRepository.findAll());
        model.addAttribute("osoby", osobaRepository.findAll());
        model.addAttribute("druzstva",druzstvoRepository.findAll());
        model.addAttribute("odohravanie",odohravanieZapasuRepository.findAll());


        return "html/zapas/detailZapasu";
    }

    @GetMapping("kartaZapasov/upravaZapasu/{id}")
    public String upravaZapasu(@PathVariable int id, Model model) {

        model.addAttribute("zapasUprava", zapasRepository.findById(id).get());


        return "html/zapas/upravaZapasu";
    }

    @PostMapping("/upravaZapasu/{id}")
    public String submitUpravaZapasu( @PathVariable  Integer id, Zapas zapas) {

        zapas.setIdZapasu(id);

        this.zapasRepository.save(zapas);



        return "redirect:/kartaZapasov";
    }
}
