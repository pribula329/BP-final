package sk.stuba.fei.BPLukasPribula.liga;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "liga")
@Entity
public class Liga {

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    @Column(name = "id_liga")
    private Integer idLiga;
    @Column(name = "nazov_liga")
    private String nazovLiga;
    @Column(name = "rocnik_liga")
    private String rocnikLiga;


}
