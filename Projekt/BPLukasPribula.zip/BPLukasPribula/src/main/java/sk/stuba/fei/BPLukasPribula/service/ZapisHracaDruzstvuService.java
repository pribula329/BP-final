package sk.stuba.fei.BPLukasPribula.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sk.stuba.fei.BPLukasPribula.repository.ZapisHracaDruzstvuRepository;
@Service
public class ZapisHracaDruzstvuService {
    @Autowired
    private ZapisHracaDruzstvuRepository zapisHracaDruzstvuRepository;

    public ZapisHracaDruzstvuService(ZapisHracaDruzstvuRepository zapisHracaDruzstvuRepository) {
        this.zapisHracaDruzstvuRepository = zapisHracaDruzstvuRepository;
    }
}
