package sk.stuba.fei.BPLukasPribula.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sk.stuba.fei.BPLukasPribula.repository.DruzstvoRepository;

@Service
public class DruzstvoService {
    @Autowired
    private DruzstvoRepository druzstvoRepository;

    public DruzstvoService(DruzstvoRepository druzstvoRepository) {

        this.druzstvoRepository = druzstvoRepository;
    }
}
