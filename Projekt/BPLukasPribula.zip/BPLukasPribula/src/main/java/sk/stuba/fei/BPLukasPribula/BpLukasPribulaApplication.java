package sk.stuba.fei.BPLukasPribula;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import sk.stuba.fei.BPLukasPribula.osoba.Osoba;
import sk.stuba.fei.BPLukasPribula.repository.DruzstvoRepository;
import sk.stuba.fei.BPLukasPribula.repository.OdohravanieZapasuRepository;
import sk.stuba.fei.BPLukasPribula.repository.OsobaRepository;
import sk.stuba.fei.BPLukasPribula.repository.ZapasRepository;
import sk.stuba.fei.BPLukasPribula.tabulka.Tabulka;
import sk.stuba.fei.BPLukasPribula.zapas.OdohravanieZapasu;
import sk.stuba.fei.BPLukasPribula.zapas.Zapas;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;


@Slf4j
@Controller
@SpringBootApplication
public class BpLukasPribulaApplication implements CommandLineRunner {
    @Autowired
    DruzstvoRepository druzstvoRepository;
    ZapasRepository zapasRepository;
    OdohravanieZapasuRepository odohravanieZapasuRepository;

    public BpLukasPribulaApplication(DruzstvoRepository druzstvoRepository, ZapasRepository zapasRepository, OdohravanieZapasuRepository odohravanieZapasuRepository) {
        this.druzstvoRepository = druzstvoRepository;
        this.zapasRepository = zapasRepository;
        this.odohravanieZapasuRepository = odohravanieZapasuRepository;
    }


    public static void main(String[] args) {

        SpringApplication.run(BpLukasPribulaApplication.class, args);
        log.info("Open in browser: http://localhost:8080/index");
    }

    @GetMapping("/index")
    public String index(Model model) {
        List<Tabulka> tabulka =body(druzstvoRepository,zapasRepository,odohravanieZapasuRepository);
        model.addAttribute("tabulka",tabulka);

        return "index";

    }

    @Override
    public void run(String... args) throws Exception {

    }

    public List<Tabulka> body(DruzstvoRepository druzstvoRepository, ZapasRepository zapasRepository, OdohravanieZapasuRepository odohravanieZapasuRepository) {
        List<Tabulka> tabulka = new ArrayList<>();
        for (int i=0; i< druzstvoRepository.findAll().size();i++){
            Tabulka druzstvo = new Tabulka(druzstvoRepository.findAll().get(i).getIdDruzstvo(),druzstvoRepository.findAll().get(i).getNazov(),0);
            tabulka.add(druzstvo);
        }

        for (int j=0; j<odohravanieZapasuRepository.findAll().size();j++){
            OdohravanieZapasu hraniZapas = odohravanieZapasuRepository.findAll().get(j);
            int domace = hraniZapas.getIdDomaciTeam();
            int hostia = hraniZapas.getIdHostujuciTeam();
            Zapas zapas = zapasRepository.getOne(hraniZapas.getIdZapas());
            if (zapas.getSkoreDomaci()>zapas.getSkoreHostia()){
                druzstvoBody(tabulka,domace,3);
                druzstvoBody(tabulka,hostia,1);
            }
            else if (zapas.getSkoreDomaci()<zapas.getSkoreHostia()){
                druzstvoBody(tabulka,domace,1);
                druzstvoBody(tabulka,hostia,3);
            }
            else {
                druzstvoBody(tabulka,domace,2);
                druzstvoBody(tabulka,hostia,2);
            }
        }


        return tabulka;
    }


    public void druzstvoBody(List<Tabulka> tabulka, int idTeam, int body){
        for (int i=0; i<tabulka.size();i++){
            if (idTeam == tabulka.get(i).getIdDruzstva()){
                int aktualneBody = tabulka.get(i).getBody();
                tabulka.get(i).setBody(body+aktualneBody);
            }
        }

    }
}
