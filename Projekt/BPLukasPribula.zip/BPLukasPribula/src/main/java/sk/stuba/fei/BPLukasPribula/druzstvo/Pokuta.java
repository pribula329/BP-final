package sk.stuba.fei.BPLukasPribula.druzstvo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "pokuty")
@Entity
public class Pokuta {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "idpokuty")
    private Integer idPokuty;
    @Column(name = "id_druzstva")
    private int idDruzstva;
    @Column(name = "id_rozhodcu")
    private int idRozhodcu;
    @Column(name = "popis")
    private String popis;
}
