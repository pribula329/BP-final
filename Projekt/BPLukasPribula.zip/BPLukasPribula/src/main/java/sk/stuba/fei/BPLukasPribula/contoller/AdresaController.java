package sk.stuba.fei.BPLukasPribula.contoller;

import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import sk.stuba.fei.BPLukasPribula.druzstvo.Adresa;
import sk.stuba.fei.BPLukasPribula.druzstvo.Druzstvo;
import sk.stuba.fei.BPLukasPribula.repository.AdresaRepository;

@Data
@Component
@Controller
public class AdresaController {
    @Autowired
    private AdresaRepository adresaRepository;

    public AdresaController(AdresaRepository adresaRepository) {
        this.adresaRepository = adresaRepository;
    }

    @GetMapping("/vytvaranieAdresy")
    public String vytvaranieAdresy(Model model) {

        model.addAttribute("adresa", new Adresa());
        return "html/vytvaranieAdresy";

    }

    @PostMapping("/vytvaranieAdresy")
    public String submitVytvaranieAdresy(@ModelAttribute Adresa adresa, Model model) {



        this.adresaRepository.save(adresa);
        return "redirect:/kartaAdries";

    }

    @GetMapping("/kartaAdries")
    public String kartaAdries( Model model) {


        model.addAttribute("adresa",adresaRepository.findAll());



        return "html/adresa/kartaAdries";
    }

    @GetMapping("kartaAdries/upravaAdresy/{id}")
    public String upravaAdresy( @PathVariable int id, Model model) {

        model.addAttribute("adresaUprava", adresaRepository.findById(id).get());


        return "html/adresa/upravaAdresy";
    }

    @PostMapping("/upravaAdresy/{id}")
    public String submitUpravaAdresy( @PathVariable  Integer id, Adresa adresa) {

        adresa.setIdAdresa(id);

        this.adresaRepository.save(adresa);



        return "redirect:/kartaAdries";
    }




}
