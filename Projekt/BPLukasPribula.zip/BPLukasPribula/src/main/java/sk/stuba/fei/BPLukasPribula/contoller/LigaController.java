package sk.stuba.fei.BPLukasPribula.contoller;

import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import sk.stuba.fei.BPLukasPribula.liga.Liga;
import sk.stuba.fei.BPLukasPribula.repository.LigaRepository;

@Data
@Component
@Controller
public class LigaController {
    @Autowired
    private LigaRepository ligaRepository;

    public LigaController(LigaRepository ligaRepository) {
        this.ligaRepository = ligaRepository;
    }

    @GetMapping("/vytvaranieLigy")
    public String vytvaranieLigy(Model model) {

        model.addAttribute("liga", new Liga());
        return "html/vytvaranieLigy";

    }

    @PostMapping("/vytvaranieLigy")
    public String submitVytvaranieLigy(@ModelAttribute Liga liga, Model model) {



        this.ligaRepository.save(liga);
        return "index";

    }

    @GetMapping("/kartaLig")
    public String kartaLig( Model model) {


        model.addAttribute("liga",ligaRepository.findAll());



        return "html/liga/kartaLig";
    }

}
