package sk.stuba.fei.BPLukasPribula.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sk.stuba.fei.BPLukasPribula.zapas.Zapas;

@Repository
public interface ZapasRepository extends JpaRepository<Zapas,Integer> {
}
