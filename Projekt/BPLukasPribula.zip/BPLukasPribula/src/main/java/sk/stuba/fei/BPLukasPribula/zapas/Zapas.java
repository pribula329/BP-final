package sk.stuba.fei.BPLukasPribula.zapas;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "zapas")
@Entity
public class Zapas {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id_zapasu")
    private Integer idZapasu;
    @Column(name = "skore_domaci")
    private int skoreDomaci;
    @Column(name = "skore_hostia")
    private int skoreHostia;
    @Column(name = "skore1")
    private int skore1;
    @Column(name = "skore2")
    private int skore2;
    @Column(name = "skore3")
    private int skore3;
    @Column(name = "skore4")
    private int skore4;
    @Column(name = "skore5")
    private int skore5;
    @Column(name = "skore6")
    private int skore6;
    @Column(name = "skore7")
    private int skore7;
    @Column(name = "skore8")
    private int skore8;
    @Column(name = "skore9")
    private int skore9;
    @Column(name = "skore10")
    private int skore10;
    @Column(name = "skore11")
    private int skore11;
    @Column(name = "skore12")
    private int skore12;
    @Column(name = "skore13")
    private int skore13;
    @Column(name = "skore14")
    private int skore14;
    @Column(name = "skore15")
    private int skore15;
    @Column(name = "skore16")
    private int skore16;

}
