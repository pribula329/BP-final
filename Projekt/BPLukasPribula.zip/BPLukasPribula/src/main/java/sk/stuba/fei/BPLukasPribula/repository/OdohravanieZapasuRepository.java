package sk.stuba.fei.BPLukasPribula.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sk.stuba.fei.BPLukasPribula.zapas.OdohravanieZapasu;
@Repository
public interface OdohravanieZapasuRepository extends JpaRepository<OdohravanieZapasu,Integer> {
}
