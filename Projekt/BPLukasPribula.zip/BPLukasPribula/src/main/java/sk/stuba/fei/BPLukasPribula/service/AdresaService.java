package sk.stuba.fei.BPLukasPribula.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sk.stuba.fei.BPLukasPribula.repository.AdresaRepository;

@Service
public class AdresaService {
    @Autowired
    private AdresaRepository adresaRepository;

    public AdresaService(AdresaRepository adresaRepository) {
        this.adresaRepository = adresaRepository;
    }
}
