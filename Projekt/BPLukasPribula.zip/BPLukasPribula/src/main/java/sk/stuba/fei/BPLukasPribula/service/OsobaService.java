package sk.stuba.fei.BPLukasPribula.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sk.stuba.fei.BPLukasPribula.repository.OsobaRepository;


@Service
public class OsobaService {
    @Autowired
    private OsobaRepository osobaRepository;

    public OsobaService(OsobaRepository osobaRepository) {

        this.osobaRepository = osobaRepository;
    }


}

