package sk.stuba.fei.BPLukasPribula.zapas;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "skorezapasov")
@Entity
public class SkoreZapasov {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "idskorezapasov")
    private Integer idSkoreZapasu;
    @Column(name = "id_domaci")
    private int idDomaci;
    @Column(name = "id_hostujuci")
    private int idHostujuci;
    @Column(name = "skore")
    private String skore;
    @Column(name = "vitaz")
    private int vitaz;
    @Column(name = "kolo")
    private int kolo;

}
