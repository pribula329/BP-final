package sk.stuba.fei.BPLukasPribula.druzstvo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "adresa")
@Entity
public class Adresa {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id_adresa")
    private Integer idAdresa;
    @Column(name = "PSČ")
    private String psc;
    @Column(name = "Mesto")
    private String mesto;
    @Column(name = "Ulica")
    private String ulica;
    @Column(name = "Číslo")
    private int cislo;


}
