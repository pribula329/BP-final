package sk.stuba.fei.BPLukasPribula.vybavenie;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "vybavenie")
@Entity
public class Vybavenie {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id_vybavenia")
    private Integer idVybavenia;
    @Column(name = "nazov_vybavenia")
    private String nazovVybavenia;
    @Column(name = "typ")
    private String typ;
}
