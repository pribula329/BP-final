package sk.stuba.fei.BPLukasPribula.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sk.stuba.fei.BPLukasPribula.repository.OdohravanieZapasuRepository;
@Service
public class OdohravanieZapasuService {
    @Autowired
    private OdohravanieZapasuRepository odohravanieZapasuRepository;

    public OdohravanieZapasuService(OdohravanieZapasuRepository odohravanieZapasuRepository) {
        this.odohravanieZapasuRepository = odohravanieZapasuRepository;
    }
}
