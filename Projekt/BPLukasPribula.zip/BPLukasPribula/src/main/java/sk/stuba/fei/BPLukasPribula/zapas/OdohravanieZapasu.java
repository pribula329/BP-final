package sk.stuba.fei.BPLukasPribula.zapas;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Table(name = "odohravaniezapasu")
@Entity
public class OdohravanieZapasu {
    @Column(name = "id_domaci_team")
    private int idDomaciTeam;
    @Column(name = "id_hostujuci_team")
    private int idHostujuciTeam;
    @Id
    @Column(name = "id_zapas")
    private int idZapas;
    @Column(name = "datum")
    private Date datum;
    @Column(name = "id_rozhodcu")
    private int idRozhodca;
    @Column(name = "id_kola")
    private int idKolo;

}
