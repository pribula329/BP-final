package sk.stuba.fei.BPLukasPribula.osoba;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import javax.persistence.*;
import java.sql.Date;


@AllArgsConstructor
@NoArgsConstructor
@Data
@Table(name = "osoba")
@Entity
public class Osoba {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id_osoba")
    private Integer idOsoba;
    @Column(name="Meno")
    public String meno;
    @Column(name="Priezvisko")
    public String priezvisko;
    @Column(name= "Datum_narodenia")
    public Date datumNarodenia;
    @Column(name="TypH")
    public boolean typH;
    @Column(name="TypR")
    public boolean typR;
    @Column(name="TypT")
    public boolean typT;


    @Override
    public String toString() {
        return "Osoba{" +
                "idOsoby=" + idOsoba +
                ", meno='" + meno + '\'' +
                ", priezvisko='" + priezvisko + '\'' +
                ", datum=" + datumNarodenia+
                ", typ1=" + typH +
                ", typ2=" + typR +
                ", typ3=" + typT +
                '}';
    }
}
