package sk.stuba.fei.BPLukasPribula.contoller;

import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import sk.stuba.fei.BPLukasPribula.druzstvo.Adresa;
import sk.stuba.fei.BPLukasPribula.druzstvo.Druzstvo;
import sk.stuba.fei.BPLukasPribula.druzstvo.Pokuta;
import sk.stuba.fei.BPLukasPribula.osoba.Osoba;
import sk.stuba.fei.BPLukasPribula.osoba.ZapisHracaDruzstvu;
import sk.stuba.fei.BPLukasPribula.repository.DruzstvoRepository;
import sk.stuba.fei.BPLukasPribula.repository.OsobaRepository;
import sk.stuba.fei.BPLukasPribula.repository.PokutaRepository;

import java.util.ArrayList;
import java.util.List;

@Data
@Component
@Controller
public class PokutaController {

    private DruzstvoRepository druzstvoRepository;
    private OsobaRepository osobaRepository;
    private PokutaRepository pokutaRepository;
    @Autowired

    public PokutaController(DruzstvoRepository druzstvoRepository, OsobaRepository osobaRepository, PokutaRepository pokutaRepository) {
        this.druzstvoRepository = druzstvoRepository;
        this.osobaRepository = osobaRepository;
        this.pokutaRepository = pokutaRepository;
    }

    @GetMapping("/vytvaraniePokuty")
    public String vytvaraniePokuty(Model model) {
        List<Druzstvo> vyberDruzstva = druzstvoRepository.findAll();
        model.addAttribute("vyberDruzstva", vyberDruzstva);
        List<Osoba> vyberRozhodcu = hladanieRozhodcov(this.osobaRepository);
        model.addAttribute("vyberRozhodcu", vyberRozhodcu);
        model.addAttribute("pokuta", new Pokuta());

        return "html/pokuta/vytvaraniePokuty";

    }

    private List<Osoba> hladanieRozhodcov(OsobaRepository osobaRepository){

        List<Osoba> najdeniRozhodcovia = new ArrayList<>();
        for (int i=0; i<osobaRepository.findAll().size(); i++){
            Osoba aktualny = osobaRepository.findAll().get(i);
            if (aktualny.isTypR()==true){
                najdeniRozhodcovia.add(osobaRepository.getOne(aktualny.getIdOsoba()));
            }
        }

        return  najdeniRozhodcovia;
    }

    @PostMapping("/vytvaraniePokuty")
    public String submitVytvaraniePokuty(@ModelAttribute Pokuta pokuta, Model model) {


        this.pokutaRepository.save(pokuta);
        return "redirect:/index";

    }

    @GetMapping("/kartaPokut")
    public String kartaPokut(Model model) {

        model.addAttribute("pokuta",pokutaRepository.findAll());
        model.addAttribute("rozhodca",osobaRepository.findAll());
        model.addAttribute("druzstva",druzstvoRepository.findAll());
        return "html/pokuta/kartaPokut";

    }
}
