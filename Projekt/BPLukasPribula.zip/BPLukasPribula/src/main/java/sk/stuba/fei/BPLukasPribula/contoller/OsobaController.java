package sk.stuba.fei.BPLukasPribula.contoller;

import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import sk.stuba.fei.BPLukasPribula.druzstvo.Druzstvo;
import sk.stuba.fei.BPLukasPribula.osoba.Osoba;
import sk.stuba.fei.BPLukasPribula.osoba.ZapisHracaDruzstvu;
import sk.stuba.fei.BPLukasPribula.repository.DruzstvoRepository;
import sk.stuba.fei.BPLukasPribula.repository.OsobaRepository;
import sk.stuba.fei.BPLukasPribula.repository.SkoreZapasovRepository;
import sk.stuba.fei.BPLukasPribula.repository.ZapisHracaDruzstvuRepository;

import java.util.ArrayList;
import java.util.List;


@Controller
@Component
@Data
public class OsobaController {


    @Autowired
    private OsobaRepository osobaRepository;
    private DruzstvoRepository druzstvoRepository;
    private ZapisHracaDruzstvuRepository zapisHracaDruzstvuRepository;
    private SkoreZapasovRepository skoreZapasovRepository;

    public OsobaController(OsobaRepository osobaRepository, DruzstvoRepository druzstvoRepository, ZapisHracaDruzstvuRepository zapisHracaDruzstvuRepository, SkoreZapasovRepository skoreZapasovRepository) {
        this.osobaRepository = osobaRepository;
        this.druzstvoRepository = druzstvoRepository;
        this.zapisHracaDruzstvuRepository = zapisHracaDruzstvuRepository;
        this.skoreZapasovRepository = skoreZapasovRepository;
    }

    @GetMapping("/vytvaranieOsoby")
    public String vytvaranieOsoby(Model model) {


        List<Druzstvo> vyberDruzstva = druzstvoRepository.findAll();
        model.addAttribute("vyberDruzstva", vyberDruzstva);

        model.addAttribute("osoba", new Osoba());
        model.addAttribute("zapis", new ZapisHracaDruzstvu());
        return "html/vytvaranieOsoby";

    }

    @PostMapping("/vytvaranieOsoby")
    public String submitVytvarenieOsoby(@ModelAttribute Osoba osoba, ZapisHracaDruzstvu zapisHracaDruzstvu,  Model model) {


        this.osobaRepository.save(osoba);
        int id = osoba.getIdOsoba();

        zapisHracaDruzstvu.setIdHraca(id);
        this.zapisHracaDruzstvuRepository.save(zapisHracaDruzstvu);
        return "redirect:/index";

    }


    @GetMapping("/kartaOsob")
    public String kartaOsob( Model model) {


        model.addAttribute("osoby",osobaRepository.findAll());



        return "html/osoba/kartaOsob";
    }

    @GetMapping("/kartaOsob/detail/{id}")
    public String detailOsoba(@PathVariable int id, Model model) {


        model.addAttribute("osobaDetail", osobaRepository.findAll().get(id));
        model.addAttribute("zapasy",skoreZapasovRepository.findAll());
        model.addAttribute("osoby",osobaRepository.findAll());

        return "html/osoba/detailOsoba";
    }


    @GetMapping("kartaOsob/detail/uprava/{id}")
    public String upravaCezDetailOsoba( @PathVariable int id, Model model) {

        model.addAttribute("osoba",  osobaRepository.findById(id).get());


        return "html/osoba/upravaOsoby";
    }

    @PostMapping("/uprava/{id}")
    public String submitUpravaCezDetailOsoba( @PathVariable  Integer id, Osoba osoba) {

        osoba.setIdOsoba(id);

        this.osobaRepository.save(osoba);



        return "redirect:/kartaOsob";
    }

}
