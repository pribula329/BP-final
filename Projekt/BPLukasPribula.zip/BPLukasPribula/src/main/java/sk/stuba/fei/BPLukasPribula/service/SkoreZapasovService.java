package sk.stuba.fei.BPLukasPribula.service;

import org.springframework.beans.factory.annotation.Autowired;
import sk.stuba.fei.BPLukasPribula.repository.SkoreZapasovRepository;

public class SkoreZapasovService {
    @Autowired
    private SkoreZapasovRepository skoreZapasovRepository;

    public SkoreZapasovService(SkoreZapasovRepository skoreZapasovRepository) {
        this.skoreZapasovRepository = skoreZapasovRepository;
    }
}
