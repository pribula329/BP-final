package sk.stuba.fei.BPLukasPribula.druzstvo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "druzstvo")
@Entity
public class Druzstvo {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id_druzstvo")
    private Integer idDruzstvo;
    @Column(name = "Nazov")
    private String nazov;
    @Column(name = "Miestnosť")
    private String miestnost;
    @Column(name = "id_adresa")
    private int idAdresa;
    @Column(name = "id_veduceho_druzstva")
    private int idVeducehoDruzstva;



}
