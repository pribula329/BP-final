package sk.stuba.fei.BPLukasPribula.osoba;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Table(name = "zapishracadruzstvu")
@Entity
public class ZapisHracaDruzstvu {
    @Id
    @Column(name = "id_hraca")
    private Integer idHraca;
    @Column(name = "id_druzstva")
    private Integer idDruzstva;
}
