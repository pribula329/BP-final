package sk.stuba.fei.BPLukasPribula.contoller;

import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import sk.stuba.fei.BPLukasPribula.druzstvo.Adresa;
import sk.stuba.fei.BPLukasPribula.druzstvo.Druzstvo;

import sk.stuba.fei.BPLukasPribula.osoba.Osoba;
import sk.stuba.fei.BPLukasPribula.osoba.ZapisHracaDruzstvu;
import sk.stuba.fei.BPLukasPribula.repository.AdresaRepository;
import sk.stuba.fei.BPLukasPribula.repository.DruzstvoRepository;
import sk.stuba.fei.BPLukasPribula.repository.OsobaRepository;
import sk.stuba.fei.BPLukasPribula.repository.ZapisHracaDruzstvuRepository;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

@Data
@Component
@Controller
public class DruzstvoController {


    private DruzstvoRepository druzstvoRepository;
    private AdresaRepository adresaRepository;
    private OsobaRepository osobaRepository;
    private ZapisHracaDruzstvuRepository zapisHracaDruzstvuRepository;
    @Autowired
    public DruzstvoController(DruzstvoRepository druzstvoRepository, AdresaRepository adresaRepository, OsobaRepository osobaRepository, ZapisHracaDruzstvuRepository zapisHracaDruzstvuRepository) {
        this.druzstvoRepository = druzstvoRepository;
        this.adresaRepository = adresaRepository;
        this.osobaRepository = osobaRepository;
        this.zapisHracaDruzstvuRepository = zapisHracaDruzstvuRepository;
    }


    @GetMapping("/vytvaranieDruzstva")
    public String vytvaranieDruzstva(Model model) {

        model.addAttribute("druzstvo", new Druzstvo());
        model.addAttribute("adresa",new Adresa());
        model.addAttribute("osoba", new Osoba());
        return "html/vytvaranieDruzstva";

    }

    @PostMapping("/vytvaranieDruzstva")
    public String submitVytvaranieDruzstva(@ModelAttribute Druzstvo druzstvo, Adresa adresa, Osoba osoba) {


        this.adresaRepository.save(adresa);
        int pocetAdries = adresaRepository.findAll().size();
        int idAdresa = adresaRepository.findAll().get(pocetAdries-1).getIdAdresa();

        osoba.setTypT(true);
        this.osobaRepository.save(osoba);
        int pocetOsob = osobaRepository.findAll().size();
        int idVeduceho = osobaRepository.findAll().get(pocetOsob-1).getIdOsoba();

        druzstvo.setIdAdresa(idAdresa);
        druzstvo.setIdVeducehoDruzstva(idVeduceho);
        this.druzstvoRepository.save(druzstvo);
        if (this.osobaRepository.getOne(idVeduceho).isTypH()){
            ZapisHracaDruzstvu zapisHracaDruzstvu = new ZapisHracaDruzstvu();
            zapisHracaDruzstvu.setIdHraca(idVeduceho);
            zapisHracaDruzstvu.setIdDruzstva(this.druzstvoRepository.findAll().get(this.druzstvoRepository.findAll().size()-1).getIdDruzstvo());
            this.zapisHracaDruzstvuRepository.save(zapisHracaDruzstvu);
        }
        return "redirect:/index";

    }

    @GetMapping("/kartaDruzstiev")
    public String kartaDruzstiev( Model model) {


        model.addAttribute("druzstva",druzstvoRepository.findAll());



        return "html/druzstvo/kartaDruzstiev";
    }

    @GetMapping("/kartaDruzstiev/detail/{id}")
    public String detailDruzstva(@PathVariable int id, Model model) {

        Druzstvo druzstvoDetail = druzstvoRepository.findAll().get(id);
        model.addAttribute("druzstvoDetail", druzstvoDetail);
        model.addAttribute("adresaDetail",adresaRepository.findById(druzstvoDetail.getIdAdresa()).get());
        model.addAttribute("veduciDetail",osobaRepository.findById(druzstvoDetail.getIdVeducehoDruzstva()).get());
        model.addAttribute("hraciDruzstva", hladanieHracov(druzstvoDetail,this.zapisHracaDruzstvuRepository,this.osobaRepository));
        return "html/druzstvo/detailDruzstva";
    }

    private List<Osoba> hladanieHracov(Druzstvo druzstvo, ZapisHracaDruzstvuRepository zapisHracaDruzstvuRepository, OsobaRepository osobaRepository){

        List<Osoba> najdenyHraci = new ArrayList<>();
        for (int i=0; i<zapisHracaDruzstvuRepository.findAll().size(); i++)
        {
            ZapisHracaDruzstvu aktualny = zapisHracaDruzstvuRepository.findAll().get(i);
            if (aktualny.getIdDruzstva() == druzstvo.getIdDruzstvo())
            {
                najdenyHraci.add(osobaRepository.getOne(aktualny.getIdHraca()));
            }
        }

        return najdenyHraci;
    }

    @GetMapping("kartaDruzstiev/detail/upravaDruzstva/{id}")
    public String upravaCezDetailDruzstvo( @PathVariable int id, Model model) {

        model.addAttribute("druzstvoUprava", druzstvoRepository.findById(id).get());
        List<Adresa> vyberAdresy = adresaRepository.findAll();
        model.addAttribute("vyberAdresy", vyberAdresy);
        List<Osoba> vyberVeduceho = osobaRepository.findAll();
        model.addAttribute("vyberVeduceho", vyberVeduceho);


        return "html/druzstvo/upravaDruzstva";
    }

    @PostMapping("/upravaDruzstva/{id}")
    public String submitUpravaCezDetailDruzstvo( @PathVariable  Integer id, Druzstvo druzstvo) {

        druzstvo.setIdDruzstvo(id);

        this.druzstvoRepository.save(druzstvo);



        return "redirect:/kartaDruzstiev";
    }


}
