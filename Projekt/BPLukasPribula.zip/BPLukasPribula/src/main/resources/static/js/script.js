
//selecty pri zapasoch
$('#druzstvoDomaci').on('change',function (){
    var hodnota = $(this).val();
    console.log(hodnota);
    //iba domaci hraci list
    var dataDomaci = filterFunkcia(hodnota,osoby,osobyIbaHraci);

    //vycistenie a prerobenieselectu
    novySelect(dataDomaci,1);

});

$('#druzstvoHostia').on('change',function (){
    var hodnota = $(this).val();
    console.log(hodnota);

    var dataHostia = filterFunkcia(hodnota,osoby,osobyIbaHraci);

    //vycistenie a prerobenieselectu
    novySelect(dataHostia,2);
});

function filterFunkcia(druzstvo, osoby, ibaHraci) {
    var idHracov = [];
    druzstvo = parseInt(druzstvo);
    for (var j=0; j<ibaHraci.length; j++){
        if (druzstvo===ibaHraci[j].idDruzstva){
            idHracov.push(ibaHraci[j].idHraca);
            console.log(ibaHraci[j].idHraca);
        }

    }
    var uzIbaHraci = [];
    for (var i=0; i<osoby.length; i++){
        var aktualnaOsoba = osoby[i];
        for (var z=0; z<idHracov.length; z++){
            console.log(idHracov[z]);
            if (aktualnaOsoba.idOsoba === idHracov[z])
            {
                uzIbaHraci.push(aktualnaOsoba);
                console.log(aktualnaOsoba);
            }
        }

    }
    return uzIbaHraci;
}

function novySelect(hraci,kod) {



    var select;


    for(var j=0; j<zapasy.listSkoreZapasov.length; j++){
        console.log("som v prvom forku");
        if(kod===1){
            select=document.getElementById('listSkoreZapasov'+j+'.idDomaci');
        }
        else if(kod===2){
            select=document.getElementById('listSkoreZapasov'+j+'.idHostujuci');
        }
        else {
            select = 0;
        }
        while (select.firstChild){
            select.removeChild(select.lastChild);
        }
        console.log(select);
        for (var i=0; i<hraci.length;i++)
        {
            $(select).append($('<option>', {
                value: hraci[i].idOsoba,
                text:  hraci[i].meno + ' ' + hraci[i].priezvisko
            }));

            console.log(hraci[i] +"som vo forku");
        }
    }

}


// statistika zakladna