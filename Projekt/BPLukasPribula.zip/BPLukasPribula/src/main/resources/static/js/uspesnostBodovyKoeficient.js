// vypis na zaciatku
window.onload = uspesnostBK(0,100);

$('#zaciatocneKoloLigy').on('change',function (){
    var hodnota = $(this).val();
    var hodnota2 = document.getElementById('konecneKoloLigy').value;
    uspesnostBK(hodnota,hodnota2);


});

$('#konecneKoloLigy').on('change',function (){
    var hodnota = $(this).val();
    var hodnota2 = document.getElementById('zaciatocneKoloLigy').value;
    uspesnostBK(hodnota2,hodnota);


});

function uspesnostBK(kolo1,kolo2) {

    var pole = []
    for (var i = kolo1; i<=kolo2;i++){

        var uspesnosti = hraci(i);


        var rozdiel = rozdiely(uspesnosti,i);

        pole.push(rozdiel);
    }

    var konecneUspesnosti = finalProgress(pole);
    konecneUspesnosti.sort(compareK);

    var tabulka = document.getElementById("tabulka");
    while (tabulka.firstChild){
        tabulka.removeChild(tabulka.lastChild);
    }
    for (var i = 0; i < konecneUspesnosti.length; i++) {
        var meno = "";
        var priezvisko = "";
        for (var j=0; j<osoby.length; j++) {
            if (osoby[j].idOsoba == konecneUspesnosti[i].id){
                meno=osoby[j].meno;
                priezvisko=osoby[j].priezvisko;

            }

        }

            var umiestnenie = i+1;
            $(tabulka).append($('<tr>',{}));
            $(tabulka).append($('<td>', {
                text: umiestnenie
            }));
            $(tabulka).append($('<td>', {
                text: konecneUspesnosti[i].id
            }));
            $(tabulka).append($('<td>', {
                text: meno
            }));
            $(tabulka).append($('<td>', {
                text: priezvisko
            }));
            $(tabulka).append($('<td>', {
                text: konecneUspesnosti[i].vyhry
            }));
            $(tabulka).append($('<td>', {
                text: konecneUspesnosti[i].zapasy
            }));
            $(tabulka).append($('<td>', {
                text: (konecneUspesnosti[i].vyhry/konecneUspesnosti[i].zapasy*100).toFixed(2) + '%'
            }));

            $(tabulka).append($('<td>', {
                text: (konecneUspesnosti[i].progres).toFixed(2)
            }));
        }



}

function finalProgress(pole) {

    var hraci = [];
    for (var j=0; j<pole[0].length;j++){
        hraci.push(pole[0][j]);
    }
    if (pole.length>1){
        for (var i=1;i<pole.length;i++){
            for (var j=0; j<pole[i].length;j++){
                var kontrola =0;
                for (var x=0;x<hraci.length;x++){
                    if (pole[i][j].id==hraci[x].id){
                        kontrola++;
                        hraci[x].vyhry = hraci[x].vyhry+pole[i][j].vyhry;
                        hraci[x].zapasy = hraci[x].zapasy+pole[i][j].zapasy;
                        if (hraci[x].progres<pole[i][j].progres){
                            hraci[x].progres=pole[i][j].progres;
                        }
                    }

                }

                if (kontrola==0){
                    hraci.push(pole[i][j]);
                }

            }
        }
    }

    return hraci;


}

function rozdiely(uspesnosti,kolo) {
    console.log(kolo)

    for (var i = 0; i < skoreZapasov.length; i++) {
        for (var j = 0; j < uspesnosti.length; j++) {
            var rozdiel = 0;
            if (uspesnosti[j].id==skoreZapasov[i].idDomaci && kolo==skoreZapasov[i].kolo ){

              var protihrac = najdiHraca(skoreZapasov[i].idHostujuci,uspesnosti);


                if (skoreZapasov[i].vitaz==1){
                    if (uspesnosti[j].koeficient>protihrac.koeficient){
                        rozdiel = uspesnosti[j].koeficient-protihrac.koeficient;
                    }
                    else {
                        rozdiel = (uspesnosti[j].koeficient-1)/2;
                    }
                    uspesnosti[j].progres = uspesnosti[j].progres+rozdiel;
                }
                else{
                    if (uspesnosti[j].koeficient>protihrac.koeficient){
                        rozdiel = (protihrac.koeficient-1)/2;
                    }
                    else {
                        rozdiel = protihrac.koeficient - uspesnosti[j].koeficient;
                    }

                    uspesnosti[j].progres = uspesnosti[j].progres-rozdiel;
                }


            }
            else if (uspesnosti[j].id==skoreZapasov[i].idHostujuci && kolo==skoreZapasov[i].kolo){

                var protihrac = najdiHraca(skoreZapasov[i].idDomaci,uspesnosti);

                if (skoreZapasov[i].vitaz==2){
                    if (uspesnosti[j].koeficient>protihrac.koeficient){
                        rozdiel = uspesnosti[j].koeficient-protihrac.koeficient;
                    }
                    else {
                        rozdiel = (uspesnosti[j].koeficient-1)/2;
                    }
                    uspesnosti[j].progres = uspesnosti[j].progres+rozdiel;
                }
                else{
                    if (uspesnosti[j].koeficient>protihrac.koeficient){
                        rozdiel = (protihrac.koeficient-1)/2;
                    }
                    else {
                        rozdiel = protihrac.koeficient - uspesnosti[j].koeficient;
                    }

                    uspesnosti[j].progres = uspesnosti[j].progres-rozdiel;
                }




            }

        }


    }

    return uspesnosti;
}

function najdiHraca(id,pole) {

    for (var i=0; i<pole.length;i++){

        if (pole[i].id==id){
            return pole[i];
        }
    }
    return 0;
}

function hraci(kolo1) {
    var uspesnosti = [];
    var hrac = new Object();
    hrac.id = skoreZapasov[0].idDomaci;
    hrac.zapasy = 0;
    hrac.vyhry = 0;
    hrac.uspesnost = 0;

    hrac.koeficient = 0;
    hrac.progres = 0;
    uspesnosti.push(hrac);

    var hrac2 = new Object();
    hrac2.id = skoreZapasov[0].idHostujuci;
    hrac2.zapasy = 0;
    hrac2.vyhry = 0;
    hrac2.uspesnost = 0;

    hrac2.koeficient = 0;
    hrac2.progres = 0;
    uspesnosti.push(hrac2);

    for (var i = 0; i < skoreZapasov.length; i++) {

        var kontrola1 = 0;
        var kontrola2 = 0;
        for (var j = 0; j < uspesnosti.length; j++) {

            for (var k = 0; k < uspesnosti.length; k++) {
                if (uspesnosti[k].id == skoreZapasov[i].idDomaci ) {
                    kontrola1++;
                }
                if (uspesnosti[k].id == skoreZapasov[i].idHostujuci) {
                    kontrola2++;
                }
            }

            if (kontrola1 == 0) {
                var hrac = new Object();
                hrac.id = skoreZapasov[i].idDomaci;
                hrac.zapasy = 0;
                hrac.vyhry = 0;
                hrac.uspesnost = 0;

                hrac.koeficient = 0;
                hrac.progres = 0;
                uspesnosti.push(hrac);
            }
            if (kontrola2 == 0) {
                var hrac2 = new Object();
                hrac2.id = skoreZapasov[i].idHostujuci;
                hrac2.zapasy = 0;
                hrac2.vyhry = 0;
                hrac2.uspesnost = 0;

                hrac2.koeficient = 0;
                hrac2.progres = 0;
                uspesnosti.push(hrac2);
            }

                if (uspesnosti[j].id==skoreZapasov[i].idDomaci && kolo1==skoreZapasov[i].kolo ){
                    uspesnosti[j].zapasy = uspesnosti[j].zapasy+1;
                    if (skoreZapasov[i].vitaz==1){
                        uspesnosti[j].vyhry = uspesnosti[j].vyhry +1;
                    }

                }
                else if (uspesnosti[j].id==skoreZapasov[i].idHostujuci && kolo1==skoreZapasov[i].kolo){

                    uspesnosti[j].zapasy = uspesnosti[j].zapasy+1;
                    if (skoreZapasov[i].vitaz==2){
                        uspesnosti[j].vyhry = uspesnosti[j].vyhry +1;
                    }

                }


            }


        }
   // uspesnosti.pop();

    var uspesnostiN = hraciSoZapasmi(uspesnosti);
    for (var k=0; k< uspesnostiN.length;k++){

        uspesnostiN[k].uspesnost = (uspesnostiN[k].vyhry/uspesnostiN[k].zapasy*100).toFixed(2);
    }




    uspesnostiN.sort(compare);

    for (var k=0; k< uspesnostiN.length;k++){

        uspesnostiN[k].koeficient=(k+1)/100+1;
        console.log(uspesnostiN[k].id +' '+uspesnostiN[k].koeficient)
    }

    return uspesnostiN;

}

function hraciSoZapasmi(uspesnosti) {
    var noveUspesnosti=[];
    for (var j=0; j< uspesnosti.length;j++){

        if(uspesnosti[j].zapasy!=0){
            noveUspesnosti.push(uspesnosti[j]);
        }

    }
    return noveUspesnosti;

}

function compare(a, b) {
    a=a.uspesnost;
    b=b.uspesnost;


    return b-a;
}

function compareK(a, b) {
    a=a.progres;
    b=b.progres;


    return b-a;
}