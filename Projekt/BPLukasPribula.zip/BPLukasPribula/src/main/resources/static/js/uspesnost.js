
// vypis na zaciatku
window.onload = uspesnost(0,100);

$('#zaciatocneKoloLigy').on('change',function (){
    var hodnota = $(this).val();
   var hodnota2 = document.getElementById('konecneKoloLigy').value;
   uspesnost(hodnota,hodnota2);


});

$('#konecneKoloLigy').on('change',function (){
    var hodnota = $(this).val();
    var hodnota2 = document.getElementById('zaciatocneKoloLigy').value;
    uspesnost(hodnota2,hodnota);


});

function uspesnost(kolo1,kolo2) {



    var uspesnosti = UspesnostiNaZaciatku(kolo1,kolo2);
    var tabulka = document.getElementById("tabulka");
    while (tabulka.firstChild){
        tabulka.removeChild(tabulka.lastChild);
    }
    var umiestnenie=1;
    for (var i = 0; i < uspesnosti.length; i++) {
        console.log(uspesnosti[i].id);
        var meno = "";
        var priezvisko = "";
        for (var j=0; j<osoby.length; j++) {
            if (osoby[j].idOsoba == uspesnosti[i].id){
                meno=osoby[j].meno;
                priezvisko=osoby[j].priezvisko;

            }

        }

    if (uspesnosti[i].zapasy!=0){
        $(tabulka).append($('<tr>',{}));
        $(tabulka).append($('<td>', {
            text: umiestnenie
        }));
        umiestnenie++;
        $(tabulka).append($('<td>', {
            text: uspesnosti[i].id
        }));
        $(tabulka).append($('<td>', {
            text: meno
        }));
        $(tabulka).append($('<td>', {
            text: priezvisko
        }));
        $(tabulka).append($('<td>', {
            text: uspesnosti[i].vyhry
        }));
        $(tabulka).append($('<td>', {
            text: uspesnosti[i].zapasy
        }));
        $(tabulka).append($('<td>', {
            text: uspesnosti[i].uspesnost + '%'
        }));
    }





    }

}


function UspesnostiNaZaciatku(kolo1, kolo2){
    var uspesnosti=[];
    var hrac = new Object();
    hrac.id = skoreZapasov[0].idDomaci;
    hrac.zapasy = 0;
    hrac.vyhry = 0;
    hrac.uspesnost=0;
    uspesnosti.push(hrac);
    console.log(uspesnosti[0]);
    var hrac2 = new Object();
    hrac2.id = skoreZapasov[0].idHostujuci;
    hrac2.zapasy = 0;
    hrac2.vyhry = 0;
    hrac.uspesnost=0;
    uspesnosti.push(hrac2);

    for (var i = 0; i < skoreZapasov.length; i++) {

        var kontrola1=0;
        var kontrola2=0;
        for (var j=0; j<uspesnosti.length;j++){

            for (var k=0; k<uspesnosti.length;k++){
                if (uspesnosti[k].id==skoreZapasov[i].idDomaci){
                    kontrola1++;
                }
                if (uspesnosti[k].id==skoreZapasov[i].idHostujuci){
                    kontrola2++;
                }
            }

            if (kontrola1==0) {
                var hrac = new Object();
                hrac.id = skoreZapasov[i].idDomaci;
                hrac.zapasy = 0;
                hrac.vyhry = 0;
                uspesnosti.push(hrac);
            }
            if (kontrola2==0){
                var hrac2 = new Object();
                hrac2.id = skoreZapasov[i].idHostujuci;
                hrac2.zapasy = 0;
                hrac2.vyhry = 0;
                uspesnosti.push(hrac2);

            }


            if (uspesnosti[j].id==skoreZapasov[i].idDomaci && kolo1<=skoreZapasov[i].kolo && kolo2>=skoreZapasov[i].kolo ){
                uspesnosti[j].zapasy = uspesnosti[j].zapasy+1;
                if (skoreZapasov[i].vitaz==1){
                    uspesnosti[j].vyhry = uspesnosti[j].vyhry +1;
                }

            }
            else if (uspesnosti[j].id==skoreZapasov[i].idHostujuci && kolo1<=skoreZapasov[i].kolo && kolo2>=skoreZapasov[i].kolo){

                uspesnosti[j].zapasy = uspesnosti[j].zapasy+1;
                if (skoreZapasov[i].vitaz==2){
                    uspesnosti[j].vyhry = uspesnosti[j].vyhry +1;
                }

            }


        }


    }
   // uspesnosti.pop();

    for (var k=0; k< uspesnosti.length;k++){

        uspesnosti[k].uspesnost = (uspesnosti[k].vyhry/uspesnosti[k].zapasy*100).toFixed(2);
    }


    uspesnosti.sort(compare)
    return uspesnosti;

}

function compare(a, b) {
    a=a.uspesnost;
    b=b.uspesnost;


    return b-a;
}