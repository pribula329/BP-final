// vypis na zaciatku
window.onload = uspesnostELO(0,100);

$('#zaciatocneKoloLigy').on('change',function (){
    var hodnota = $(this).val();
    var hodnota2 = document.getElementById('konecneKoloLigy').value;
    uspesnostELO(hodnota,hodnota2);


});

$('#konecneKoloLigy').on('change',function (){
    var hodnota = $(this).val();
    var hodnota2 = document.getElementById('zaciatocneKoloLigy').value;
    uspesnostELO(hodnota2,hodnota);


});



function uspesnostELO(kolo1,kolo2) {



    var uspesnosti2 = hraci(kolo1,kolo2);
    var uspesnosti = vykonnsti(uspesnosti2,kolo1,kolo2);
    uspesnosti.sort(compare);
    var tabulka = document.getElementById("tabulka");
    while (tabulka.firstChild){
        tabulka.removeChild(tabulka.lastChild);
    }
    for (var i = 0; i < uspesnosti.length; i++) {
        console.log(uspesnosti[i].id);
        var meno = "";
        var priezvisko = "";
        for (var j=0; j<osoby.length; j++) {
            if (osoby[j].idOsoba == uspesnosti[i].id){
                meno=osoby[j].meno;
                priezvisko=osoby[j].priezvisko;

            }

        }

             var umiestnenie = i+1;
            $(tabulka).append($('<tr>',{}));
            $(tabulka).append($('<td>', {
                text: umiestnenie
            }));
            $(tabulka).append($('<td>', {
                text: uspesnosti[i].id
            }));
            $(tabulka).append($('<td>', {
                text: meno
            }));
            $(tabulka).append($('<td>', {
                text: priezvisko
            }));
            $(tabulka).append($('<td>', {
                text: uspesnosti[i].vyhry
            }));
            $(tabulka).append($('<td>', {
                text: uspesnosti[i].zapasy
            }));
            $(tabulka).append($('<td>', {
                text: uspesnosti[i].uspesnost + '%'
            }));
            $(tabulka).append($('<td>', {
                text: uspesnosti[i].ELO
            }));






    }

}


function hraci(kolo1, kolo2){
    var uspesnosti=[];
    var hrac = new Object();
    hrac.id = skoreZapasov[0].idDomaci;
    hrac.zapasy = 0;
    hrac.vyhry = 0;
    hrac.uspesnost=0;
    hrac.ELO=500;
    uspesnosti.push(hrac);
    console.log(uspesnosti[0]);
    var hrac2 = new Object();
    hrac2.id = skoreZapasov[0].idHostujuci;
    hrac2.zapasy = 0;
    hrac2.vyhry = 0;
    hrac2.uspesnost=0;
    hrac2.ELO=500;
    uspesnosti.push(hrac2);

    for (var i = 0; i < skoreZapasov.length; i++) {

        var kontrola1=0;
        var kontrola2=0;
        for (var j=0; j<uspesnosti.length;j++){

            for (var k=0; k<uspesnosti.length;k++){
                if (uspesnosti[k].id==skoreZapasov[i].idDomaci){
                    kontrola1++;
                }
                if (uspesnosti[k].id==skoreZapasov[i].idHostujuci){
                    kontrola2++;
                }
            }

            if (kontrola1==0) {
                var hrac = new Object();
                hrac.id = skoreZapasov[i].idDomaci;
                hrac.zapasy = 0;
                hrac.vyhry = 0;
                hrac.uspesnost=0;
                hrac.ELO=500;
                uspesnosti.push(hrac);
            }
            if (kontrola2==0){
                var hrac2 = new Object();
                hrac2.id = skoreZapasov[i].idHostujuci;
                hrac2.zapasy = 0;
                hrac2.vyhry = 0;
                hrac2.uspesnost=0;
                hrac2.ELO=500;
                uspesnosti.push(hrac2);

            }


            if (uspesnosti[j].id==skoreZapasov[i].idDomaci && kolo1<=skoreZapasov[i].kolo && kolo2>=skoreZapasov[i].kolo ){
                uspesnosti[j].zapasy = uspesnosti[j].zapasy+1;
                if (skoreZapasov[i].vitaz==1){
                    uspesnosti[j].vyhry = uspesnosti[j].vyhry +1;
                }

            }
            else if (uspesnosti[j].id==skoreZapasov[i].idHostujuci && kolo1<=skoreZapasov[i].kolo && kolo2>=skoreZapasov[i].kolo){

                uspesnosti[j].zapasy = uspesnosti[j].zapasy+1;
                if (skoreZapasov[i].vitaz==2){
                    uspesnosti[j].vyhry = uspesnosti[j].vyhry +1;
                }

            }


        }


    }
  //  uspesnosti.pop();

    for (var k=0; k< uspesnosti.length;k++){

        uspesnosti[k].uspesnost = (uspesnosti[k].vyhry/uspesnosti[k].zapasy*100).toFixed(2);
    }



    var hraci= hraciSoZapasmi(uspesnosti);

    return hraci;

}

function compare(a, b) {
    a=a.ELO;
    b=b.ELO;


    return b-a;
}

function hraciSoZapasmi(uspesnosti) {
    var noveUspesnosti=[];
    for (var j=0; j< uspesnosti.length;j++){

        if(uspesnosti[j].zapasy!=0){
            noveUspesnosti.push(uspesnosti[j]);
        }

    }
    return noveUspesnosti;

}

function zapasyKol(kolo1,kolo2) {
    var zapasy = [];

    for (var i = 0; i<skoreZapasov.length;i++){

        if (skoreZapasov[i].kolo>=kolo1 && skoreZapasov[i].kolo<=kolo2)
        {
            zapasy.push(skoreZapasov[i]);
        }
    }

    return zapasy;

}

function najdiHraca(hraci,id){
    for (var j=0;j<hraci.length;j++){
        if (hraci[j].id===id){
            return hraci[j];
        }
    }
    return 0;
}

function vykonnsti(hraci,kolo1,kolo2){

    var zapasy= zapasyKol(kolo1, kolo2);
    console.log(zapasy.length);
    for (var i = 0; i<zapasy.length;i++){
        var domaci = najdiHraca(hraci,zapasy[i].idDomaci);
        var hostujuci = najdiHraca(hraci,zapasy[i].idHostujuci);
        var mocninaD = (hostujuci.ELO-domaci.ELO)/400 ;
        console.log("kolo "+i+" "+mocninaD);
        var  vysledokMocninyD = Math.pow(10,mocninaD);
        console.log("kolo "+i+" "+vysledokMocninyD);
        var sumaD=1/(1+vysledokMocninyD);
        var mocninaH =(domaci.ELO-hostujuci.ELO)/400 ;
        var  vysledokMocninyH = Math.pow(10,mocninaH);
        var sumaH=1/(1+vysledokMocninyH);
       if (zapasy[i].vitaz == 1){
            console.log(domaci.ELO + "******"+hostujuci.ELO);
           upravHraca(hraci,zapasy[i].idDomaci,16*(1-sumaD));
           upravHraca(hraci,zapasy[i].idHostujuci,16*(0-sumaH));
       }
       else {
           upravHraca(hraci,zapasy[i].idDomaci,16*(0-sumaD));
           upravHraca(hraci,zapasy[i].idHostujuci,16*(1-sumaH));
       }

    }

    return hraci;


}

function upravHraca(hraci,id,suma){
    for (var j=0;j<hraci.length;j++){
        if (hraci[j].id===id){
            hraci[j].ELO = hraci[j].ELO + parseInt(Math.round(suma).toFixed(2));
            break;
        }
    }

}