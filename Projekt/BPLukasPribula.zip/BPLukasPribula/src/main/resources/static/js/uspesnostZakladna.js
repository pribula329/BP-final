// vypis na zaciatku
window.onload = uspesnost(0,100);

$('#zaciatocneKoloLigy').on('change',function (){
    var hodnota = $(this).val();
    var hodnota2 = document.getElementById('konecneKoloLigy').value;
    uspesnost(hodnota,hodnota2);


});

$('#konecneKoloLigy').on('change',function (){
    var hodnota = $(this).val();
    var hodnota2 = document.getElementById('zaciatocneKoloLigy').value;
    uspesnost(hodnota2,hodnota);


});

function uspesnost(kolo1,kolo2) {



    var uspesnosti = UspesnostiNaZaciatku(kolo1);
    var uspesnostiProgres = progress(uspesnosti,kolo1,kolo2);
    var tabulka = document.getElementById("tabulka");
    while (tabulka.firstChild){
        tabulka.removeChild(tabulka.lastChild);
    }
    var umiestnenie=1;
    for (var i = 0; i < uspesnostiProgres.length; i++) {
        console.log(uspesnostiProgres[i].id);
        var meno = "";
        var priezvisko = "";
        for (var j=0; j<osoby.length; j++) {
            if (osoby[j].idOsoba == uspesnostiProgres[i].id){
                meno=osoby[j].meno;
                priezvisko=osoby[j].priezvisko;

            }

        }

        if (uspesnostiProgres[i].zapasy!=0){
            $(tabulka).append($('<tr>',{}));
            $(tabulka).append($('<td>', {
                text: umiestnenie
            }));
            umiestnenie++;
            $(tabulka).append($('<td>', {
                text: uspesnostiProgres[i].id
            }));
            $(tabulka).append($('<td>', {
                text: meno
            }));
            $(tabulka).append($('<td>', {
                text: priezvisko
            }));
            $(tabulka).append($('<td>', {
                text: uspesnostiProgres[i].vyhry
            }));
            $(tabulka).append($('<td>', {
                text: uspesnostiProgres[i].zapasy
            }));
            $(tabulka).append($('<td>', {
                text: uspesnostiProgres[i].uspesnostN + '%'
            }));
            $(tabulka).append($('<td>', {
                text: uspesnostiProgres[i].stareUmiestnenie
            }));
            $(tabulka).append($('<td>', {
                text: uspesnostiProgres[i].noveUmiestnenie
            }));
            $(tabulka).append($('<td>', {
                text: uspesnostiProgres[i].progres
            }));
        }





    }

}

function progress(uspesnosti,kolo1,kolo2) {

    for (var i = 0; i < skoreZapasov.length; i++) {

        for (var j=0; j<uspesnosti.length;j++){



            if (uspesnosti[j].id==skoreZapasov[i].idDomaci && kolo1<=skoreZapasov[i].kolo && kolo2>=skoreZapasov[i].kolo ){
                uspesnosti[j].zapasy = uspesnosti[j].zapasy+1;
                if (skoreZapasov[i].vitaz==1){
                    uspesnosti[j].vyhry = uspesnosti[j].vyhry +1;
                }

            }
            else if (uspesnosti[j].id==skoreZapasov[i].idHostujuci && kolo1<=skoreZapasov[i].kolo && kolo2>=skoreZapasov[i].kolo){

                uspesnosti[j].zapasy = uspesnosti[j].zapasy+1;
                if (skoreZapasov[i].vitaz==2){
                    uspesnosti[j].vyhry = uspesnosti[j].vyhry +1;
                }

            }


        }


    }

    for (var k=0; k< uspesnosti.length;k++){

        uspesnosti[k].uspesnostN = (uspesnosti[k].vyhry/uspesnosti[k].zapasy*100).toFixed(2);
    }


    var noveUspesnosti= hraciSoZapasmi(uspesnosti);


    noveUspesnosti.sort(compareS);
    for (var i =0; i<noveUspesnosti.length;i++){
        noveUspesnosti[i].stareUmiestnenie=i+1;
    }
    noveUspesnosti.sort(compareN);
    for (var i =0; i<noveUspesnosti.length;i++){
        noveUspesnosti[i].noveUmiestnenie=i+1;
    }


    for (var k=0; k<noveUspesnosti.length;k++){
        noveUspesnosti[k].noveUmiestnenie=k+1;
        noveUspesnosti[k].progres=noveUspesnosti[k].stareUmiestnenie-noveUspesnosti[k].noveUmiestnenie;
    }
    noveUspesnosti.sort(compareProgress);
    return noveUspesnosti;


}

function hraciSoZapasmi(uspesnosti) {
    var noveUspesnosti=[];
    for (var j=0; j< uspesnosti.length;j++){

        if(uspesnosti[j].zapasy!=0){
            noveUspesnosti.push(uspesnosti[j]);
        }

    }
    return noveUspesnosti;

}

function UspesnostiNaZaciatku(kolo1){
    var uspesnosti=[];
    var hrac = new Object();
    hrac.id = skoreZapasov[0].idDomaci;
    hrac.zapasy = 0;
    hrac.vyhry = 0;
    hrac.uspesnostS=0;
    hrac.uspesnostN=0;
    hrac.stareUmiestnenie =0;
    hrac.noveUmiestnenie =0;
    hrac.progres =0;
    uspesnosti.push(hrac);
    console.log(uspesnosti[0]);
    var hrac2 = new Object();
    hrac2.id = skoreZapasov[0].idHostujuci;
    hrac2.zapasy = 0;
    hrac2.vyhry = 0;
    hrac.uspesnostS=0;
    hrac.uspesnostN=0;
    uspesnosti.push(hrac2);

    for (var i = 0; i < skoreZapasov.length; i++) {

        var kontrola1=0;
        var kontrola2=0;
        for (var j=0; j<uspesnosti.length;j++){

            for (var k=0; k<uspesnosti.length;k++){
                if (uspesnosti[k].id==skoreZapasov[i].idDomaci){
                    kontrola1++;
                }
                if (uspesnosti[k].id==skoreZapasov[i].idHostujuci){
                    kontrola2++;
                }
            }

            if (kontrola1==0) {
                var hrac = new Object();
                hrac.id = skoreZapasov[i].idDomaci;
                hrac.zapasy = 0;
                hrac.vyhry = 0;
                hrac.uspesnostS=0;
                hrac.uspesnostN=0;
                hrac.stareUmiestnenie =0;
                hrac.noveUmiestnenie =0;
                hrac.progres =0;
                uspesnosti.push(hrac);
            }
            if (kontrola2==0){
                var hrac2 = new Object();
                hrac2.id = skoreZapasov[i].idHostujuci;
                hrac2.zapasy = 0;
                hrac2.vyhry = 0;
                hrac.uspesnostS=0;
                hrac.uspesnostN=0;
                hrac.stareUmiestnenie =0;
                hrac.noveUmiestnenie =0;
                hrac.progres =0;
                uspesnosti.push(hrac2);

            }


            if (uspesnosti[j].id==skoreZapasov[i].idDomaci && kolo1>skoreZapasov[i].kolo ){
                uspesnosti[j].zapasy = uspesnosti[j].zapasy+1;
                if (skoreZapasov[i].vitaz==1){
                    uspesnosti[j].vyhry = uspesnosti[j].vyhry +1;
                }

            }
            else if (uspesnosti[j].id==skoreZapasov[i].idHostujuci && kolo1>skoreZapasov[i].kolo){

                uspesnosti[j].zapasy = uspesnosti[j].zapasy+1;
                if (skoreZapasov[i].vitaz==2){
                    uspesnosti[j].vyhry = uspesnosti[j].vyhry +1;
                }

            }


        }


    }
  //  uspesnosti.pop();

    for (var k=0; k< uspesnosti.length;k++){

        uspesnosti[k].uspesnostS = (uspesnosti[k].vyhry/uspesnosti[k].zapasy*100).toFixed(2);
    }


    uspesnosti.sort(compareS);
    for (var k=0; k<uspesnosti.length;k++){
        uspesnosti[k].zapasy = 0;
        uspesnosti[k].vyhry = 0;
        uspesnosti[k].uspesnost=0;
    }
    return uspesnosti;

}



function compareS(a, b) {
    a=a.uspesnostS;
    b=b.uspesnostS;


    return b-a;
}
function compareN(a, b) {
    a=a.uspesnostN;
    b=b.uspesnostN;


    return b-a;
}

function compareProgress(a, b) {
    a=a.progres;
    b=b.progres;


    return b-a;
}