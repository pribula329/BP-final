package sk.stuba.fei.BPLukasPribula;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BpLukasPribulaApplicationTests {

    @Test
    void contextLoads() {
    }

}
