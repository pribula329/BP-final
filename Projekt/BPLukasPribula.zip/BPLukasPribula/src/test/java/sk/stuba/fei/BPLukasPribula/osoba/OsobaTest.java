package sk.stuba.fei.BPLukasPribula.osoba;

import static org.junit.jupiter.api.Assertions.*;

class OsobaTest {

}